<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $departure = isset($_POST['departure']) ? $_POST['departure'] : '';
    $arrival = isset($_POST['arrival']) ? $_POST['arrival'] : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';



    
    $departure = filter_var($departure, FILTER_SANITIZE_STRING);
    $arrival = filter_var($arrival, FILTER_SANITIZE_STRING);
    $date = filter_var($date, FILTER_SANITIZE_STRING);

    
    if (empty($departure) || empty($arrival) || empty($date)) {
        $error_message = "Please fill in all the required fields.";
        
        echo "<p style='color: red;'>Error: " . htmlspecialchars($error_message) . "</p>";
        exit;
    }

    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "airlines";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $sql = "SELECT COUNT(*) AS available_seats 
            FROM flights 
            WHERE departure_city = ? AND arrival_city = ? AND departure_date = ?";

    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $departure, $arrival, $date);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $available_seats = $row["available_seats"];
        echo "<p style='color: green;'>Available seats for flights from " . htmlspecialchars($departure) . " to " . htmlspecialchars($arrival) . " on " . htmlspecialchars($date) . ": " . htmlspecialchars($available_seats) . "</p>";

        
        echo "<p><a href='booking.html?departure=" . urlencode($departure) . "&arrival=" . urlencode($arrival) . "&date=" . urlencode($date) . "'>Book Now</a></p>";

    } else {
        echo "<p>No flights found for the selected criteria.</p>";
    }

    
    $stmt->close();
    $conn->close();

} else {
    
    echo "<p>This page is for processing flight search results.</p>";
}
?>